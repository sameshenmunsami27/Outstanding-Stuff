
"""Django's command-line utility for administrative tasks."""
import os
import sys


def main():
    """Running administrative tasks."""
    os.environ.setdefault('DJANGO_SETTINGS_MODULE',
                          'outstanding_stuff.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
          ) from exc
    execute_from_command_line(sys.argv)


if __name__ == '__main__':
    main()
