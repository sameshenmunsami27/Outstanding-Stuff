from django.core.exceptions import PermissionDenied
import time
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.core.mail import EmailMultiAlternatives, send_mail
from django.utils.html import strip_tags
from django.conf import settings
from django.utils.http import urlsafe_base64_encode
from django.utils.encoding import force_bytes
from django.contrib.auth.tokens import default_token_generator
from django.template.loader import render_to_string  # Added for better email
# formatting
from .models import Product, Profile, Store, Order, Review

# Global variable to stop multiple emails on Windows
LAST_EMAIL_TIME = 0

# 1. GENERAL VIEWS


def home(request):
    category_name = request.GET.get("category")
    search_query = request.GET.get("search")
    products = Product.objects.all()

    if category_name:
        products = products.filter(category__iexact=category_name)
    if search_query:
        products = products.filter(name__icontains=search_query)

    return render(
        request,
        "base.html",
        {
            "products": products,
            "selected_category": category_name,
            "search_query": search_query,
        },
    )


def product_detail(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    reviews = product.reviews.all().order_by("-created_at")

    if request.method == "POST" and request.user.is_authenticated:
        rating = request.POST.get("rating")
        comment = request.POST.get("comment")
        has_purchased = Order.objects.filter(
            user=request.user, product=product
        ).exists()

        Review.objects.create(
            product=product,
            buyer=request.user,
            rating=rating,
            comment=comment,
            is_verified=has_purchased,
        )
        return redirect("product_detail", product_id=product.id)

    return render(
        request, "product_detail.html", {"product": product,
                                         "reviews": reviews}
    )


# 2. AUTHENTICATION VIEWS


def register(request):
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        user_type = request.POST.get("user_type")
        email = request.POST.get("email")

        if form.is_valid():
            user = form.save(commit=False)
            user.email = email
            user.save()
            Profile.objects.create(user=user, user_type=user_type)
            login(request, user)
            return redirect("vendor_dashboard" if user_type ==
                            "vendor" else "home")
    else:
        form = UserCreationForm()
    return render(request, "register.html", {"form": form})


def login_view(request):
    if request.method == "POST":
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect("home")
    else:
        form = AuthenticationForm()
    return render(request, "login.html", {"form": form})


def logout_view(request):
    logout(request)
    return redirect("home")


# 3. PASSWORD RESET


def simple_reset_request(request):
    global LAST_EMAIL_TIME
    if request.method == "POST":
        current_time = time.time()
        if current_time - LAST_EMAIL_TIME < 15:
            return redirect("password_reset_done")

        LAST_EMAIL_TIME = current_time
        email = request.POST.get("email")
        users = User.objects.filter(email=email)

        if users.exists():
            for user in users:
                token = default_token_generator.make_token(user)
                uid = urlsafe_base64_encode(force_bytes(user.pk))
                link = (
                    f"http://{request.get_host()}/password-reset-confirm/"
                    f"{uid}/{token}/"
                )

                send_mail(
                    "Password Reset Request",
                    (
                        f"Hello {user.username},\n\n"
                        "Click the link below to reset your password. "
                        "This link will expire in 3 hours:\n\n"
                        f"{link}"
                    ),
                    settings.DEFAULT_FROM_EMAIL,
                    [email],
                    fail_silently=False,
                )
        return redirect("password_reset_done")

    return render(request, "password_reset.html")


# 4. VENDOR MANAGEMENT


@login_required
def vendor_dashboard(request):
    if request.user.profile.user_type != "vendor":
        raise PermissionDenied  # This triggers a 403.html page
    stores = Store.objects.filter(vendor=request.user)
    return render(request, "vendor_dashboard.html", {"stores": stores})


@login_required
def add_store(request):
    if request.method == "POST":
        Store.objects.create(
            vendor=request.user,
            name=request.POST.get("name"),
            description=request.POST.get("description"),
        )
        return redirect("vendor_dashboard")
    return render(request, "add_store.html")


@login_required
def store_detail(request, store_id):
    store = get_object_or_404(Store, id=store_id, vendor=request.user)
    products = store.products.all()
    return render(request, "store_detail.html", {"store": store,
                                                 "products": products})


@login_required
def delete_store(request, store_id):
    store = get_object_or_404(Store, id=store_id, vendor=request.user)
    store.delete()
    return redirect("vendor_dashboard")


@login_required
def add_product(request, store_id):
    store = get_object_or_404(Store, id=store_id, vendor=request.user)
    if request.method == "POST":
        Product.objects.create(
            store=store,
            name=request.POST.get("name"),
            category=request.POST.get("category"),
            price=request.POST.get("price"),
            stock=request.POST.get("stock"),
            image=request.FILES.get("image"),
        )
        return redirect("store_detail", store_id=store.id)
    return render(request, "add_products.html", {"store": store})


@login_required
def edit_product(request, product_id):
    product = get_object_or_404(Product, id=product_id,
                                store__vendor=request.user)
    if request.method == "POST":
        product.name = request.POST.get("name")
        product.price = request.POST.get("price")
        product.stock = request.POST.get("stock")
        if request.FILES.get("image"):
            product.image = request.FILES.get("image")
        product.save()
        return redirect("store_detail", store_id=product.store.id)
    return render(request, "edit_product.html", {"product": product})


@login_required
def delete_product(request, product_id):
    product = get_object_or_404(Product, id=product_id,
                                store__vendor=request.user)
    store_id = product.store.id
    product.delete()
    return redirect("store_detail", store_id=store_id)


# 5. BUYER & CHECKOUT


@login_required
def add_to_cart(request, product_id):
    if request.method == "POST":
        qty = int(request.POST.get("quantity", 1))
        cart = request.session.get("cart", {})
        pid = str(product_id)
        cart[pid] = cart.get(pid, 0) + qty
        request.session["cart"] = cart
        request.session.modified = True
    return redirect("view_cart")


@login_required
def view_cart(request):
    cart = request.session.get("cart", {})
    cart_items = []
    total = 0
    for pid, qty in cart.items():
        product = get_object_or_404(Product, id=pid)
        subtotal = product.price * qty
        total += subtotal
        cart_items.append(
            {"product": product, "quantity": qty, "total_price": subtotal,
             "id": pid}
        )
    return render(request, "cart.html", {"cart_items": cart_items,
                                         "total": total})


@login_required
def remove_from_cart(request, item_id):
    cart = request.session.get("cart", {})
    item_id_str = str(item_id)
    if item_id_str in cart:
        del cart[item_id_str]
        request.session["cart"] = cart
        request.session.modified = True
    return redirect("view_cart")


@login_required
def checkout(request):
    cart = request.session.get("cart", {})
    if not cart:
        return redirect("home")

    cart_items_data = []
    total = 0
    for pid, qty in cart.items():
        product = get_object_or_404(Product, id=pid)
        subtotal = product.price * qty
        total += subtotal
        product.stock -= qty
        product.save()
        Order.objects.create(user=request.user, product=product)
        cart_items_data.append(
            {"name": product.name, "qty": qty, "price": product.price}
        )

    # Use of HTML Template
    context = {
        "customer_name": request.user.username,
        "items": cart_items_data,
        "total_price": total,
    }

    html_content = render_to_string("invoice_email.html", context)
    text_content = strip_tags(html_content)  # Plain text
    # version for old email apps

    msg = EmailMultiAlternatives(
        "Your Invoice from Outstanding Stuff",
        text_content,
        settings.DEFAULT_FROM_EMAIL,
        [request.user.email],
    )
    msg.attach_alternative(html_content, "text/html")

    try:
        msg.send()
    except Exception:
        pass

    request.session["cart"] = {}
    request.session.modified = True
    return redirect("checkout_success")


def checkout_success(request):
    return render(request, "checkout_success.html")
