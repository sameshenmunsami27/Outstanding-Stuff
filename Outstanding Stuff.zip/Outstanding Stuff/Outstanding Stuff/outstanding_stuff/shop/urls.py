from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    # General
    path("", views.home, name="home"),
    path("product/<int:product_id>/", views.product_detail,
         name="product_detail"),
    #  Authentication
    path("register/", views.register, name="register"),
    path("login/", views.login_view, name="login"),
    path("logout/", views.logout_view, name="logout"),
    # Simple Password Reset (3-Hour Expiry)
    path("password-reset/", views.simple_reset_request, name="password_reset"),
    path(
        "password-reset/done/",
        auth_views.PasswordResetDoneView.as_view(
            template_name="password_reset_done.html"
        ),
        name="password_reset_done",
    ),
    path(
        "password-reset-confirm/<uidb64>/<token>/",
        auth_views.PasswordResetConfirmView.as_view(
            template_name="password_reset_confirm.html"
        ),
        name="password_reset_confirm",
    ),
    path(
        "password-reset-complete/",
        auth_views.PasswordResetCompleteView.as_view(
            template_name="password_reset_complete.html"
        ),
        name="password_reset_complete",
    ),
    #  Vendor & Store Management
    path("dashboard/", views.vendor_dashboard, name="vendor_dashboard"),
    path("store/add/", views.add_store, name="add_store"),
    path("store/<int:store_id>/", views.store_detail, name="store_detail"),
    path(
        "store/delete/<int:store_id>/", views.delete_store, name="delete_store"
    ),
    #  Product Management
    path("store/<int:store_id>/product/add/", views.add_product,
         name="add_product"),
    path("product/edit/<int:product_id>/", views.edit_product,
         name="edit_product"),
    path(
        "product/delete/<int:product_id>/", views.delete_product,
        name="delete_product"
    ),
    # --- Cart & Checkout (Session-based) ---
    path("cart/", views.view_cart, name="view_cart"),
    path("cart/add/<int:product_id>/", views.add_to_cart, name="add_to_cart"),
    path("cart/remove/<int:item_id>/", views.remove_from_cart,
         name="remove_from_cart"),
    path("checkout/", views.checkout, name="checkout"),
    path("checkout/success/", views.checkout_success, name="checkout_success"),
]
