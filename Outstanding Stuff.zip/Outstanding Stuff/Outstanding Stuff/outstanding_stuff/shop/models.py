from django.db import models
from django.contrib.auth.models import User


# 1. USER PROFILE: Distinguishes between Vendors and Buyers
class Profile(models.Model):
    USER_TYPES = (("vendor", "Vendor"), ("buyer", "Buyer"))
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    user_type = models.CharField(max_length=10, choices=USER_TYPES)

    def __str__(self):
        return f"{self.user.username} ({self.user_type})"


# 2. STORE: Owned by a Vendor
class Store(models.Model):
    vendor = models.ForeignKey(User, on_delete=models.CASCADE,
                               related_name="stores")
    name = models.CharField(max_length=255)
    description = models.TextField()

    def __str__(self):
        return self.name


# 3. PRODUCT: Belongs to a Store and a Category
class Product(models.Model):
    CATEGORIES = [
        ("Appliances", "Appliances"),
        ("Liquor", "Liquor"),
        ("Pantry", "Pantry"),
        ("Home and Furniture", "Home and Furniture"),
    ]

    store = models.ForeignKey(Store, on_delete=models.CASCADE,
                              related_name="products")
    name = models.CharField(max_length=255)
    category = models.CharField(max_length=50, choices=CATEGORIES)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    stock = models.IntegerField()
    image = models.ImageField(upload_to="products/", null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} - {self.category}"


# 4. ORDER: Records successful purchases (Needed for Verified Reviews)
class Order(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    purchase_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} purchased {self.product.name}"


# 5. REVIEW: Left by Buyers on Products
class Review(models.Model):
    product = models.ForeignKey(
        Product, on_delete=models.CASCADE, related_name="reviews"
    )
    buyer = models.ForeignKey(User, on_delete=models.CASCADE)

    # Updated with default to prevent migration errors
    title = models.CharField(max_length=100, default="Product Review")
    rating = models.IntegerField(default=5)
    comment = models.TextField()

    is_verified = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.title} - {self.product.name} by {self.buyer.username}"


# 6. CART ITEM: Used for database-backed carts
class CartItem(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    added_at = models.DateTimeField(auto_now_add=True)

    def total_price(self):
        return self.product.price * self.quantity

    def __str__(self):
        return f"{self.quantity} x {self.product.name} ({self.user.username})"
